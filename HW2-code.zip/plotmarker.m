function h = plotmarker( markerPos, color)

plot( markerPos(1), markerPos(2), '.', 'linewidth', 5, 'Color', ...
      color);

