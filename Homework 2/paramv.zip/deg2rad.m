function r = deg2rad(d)
r = d / 180 * pi;
